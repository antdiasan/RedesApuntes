# Unidad 5: Interconexión de Equipos en Redes Locales

## Introducción

En esta unidad, exploraremos los conceptos fundamentales para poder segmentar redes y poder enviar paquetes de información a través de los distintos dispositivos de comunicación




